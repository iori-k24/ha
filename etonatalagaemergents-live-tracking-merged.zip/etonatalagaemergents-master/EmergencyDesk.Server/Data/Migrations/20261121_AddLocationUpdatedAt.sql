-- Apply once to an existing EmergencyDesk database before deploying live tracking.
-- EnsureCreated() creates new databases but does not add columns to existing tables.
ALTER TABLE `Incidents`
    ADD COLUMN `LocationUpdatedAt` datetime(6) NULL;
