using System.ComponentModel;
using System.Globalization;
using System.IO;
using System.Text.Json;
using System.Windows;
using System.Windows.Threading;
using EmergencyDesk.ViewModels;
using Microsoft.Web.WebView2.Core;

namespace EmergencyDesk.Views;

public partial class MainWindow : Window
{
    private readonly MainViewModel _vm;
    private bool _mapReady;

    public MainWindow()
    {
        InitializeComponent();
        DataContext = _vm = new MainViewModel();

        _vm.PropertyChanged += OnVmPropertyChanged;
        Loaded += async (_, _) => await InitMapAsync();
        Closed += (_, _) =>
        {
            _vm.PropertyChanged -= OnVmPropertyChanged;
            MapView.Dispose();
        };
    }

    private async Task InitMapAsync()
    {
        try
        {
            await MapView.EnsureCoreWebView2Async();

            // Serve Assets/map.html from a virtual https host so map tiles get a proper Referer.
            var assets = Path.Combine(AppContext.BaseDirectory, "Assets");
            MapView.CoreWebView2.SetVirtualHostNameToFolderMapping(
                "emergency.local", assets, CoreWebView2HostResourceAccessKind.Allow);

            MapView.CoreWebView2.NavigationCompleted += (_, _) =>
            {
                _mapReady = true;
                UpdateMap();
            };
            MapView.CoreWebView2.Navigate("https://emergency.local/map.html");
        }
        catch (Exception ex)
        {
            _vm.StatusMessage = "Map unavailable (is the WebView2 runtime installed?): " + ex.Message;
        }
    }

    private void OnVmPropertyChanged(object? sender, PropertyChangedEventArgs e)
    {
        // The list is rebuilt on every refresh, so the selection briefly becomes null and is then
        // restored. Waiting until the dispatcher is idle avoids the marker flickering away.
        if (e.PropertyName == nameof(MainViewModel.SelectedIncident))
            Dispatcher.BeginInvoke(new Action(UpdateMap), DispatcherPriority.Background);
    }

    private async void UpdateMap()
    {
        if (!_mapReady || MapView.CoreWebView2 is null) return;

        var i = _vm.SelectedIncident;
        string script;
        if (i is { HasLocation: true })
        {
            var lat = i.Latitude.ToString(CultureInfo.InvariantCulture);
            var lng = i.Longitude.ToString(CultureInfo.InvariantCulture);
            var label = JsonSerializer.Serialize($"#{i.Id} {i.Type} · {i.ReporterName}");
            script = $"setIncident({i.Id}, {lat}, {lng}, {label}, {(i.IsLive ? "true" : "false")});";
        }
        else
        {
            script = "clearIncident();";
        }

        try { await MapView.CoreWebView2.ExecuteScriptAsync(script); }
        catch { /* map not ready yet, next refresh will retry */ }
    }
}
