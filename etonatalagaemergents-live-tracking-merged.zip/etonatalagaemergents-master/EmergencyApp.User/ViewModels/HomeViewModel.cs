using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using EmergencyApp.User.Models;
using EmergencyApp.User.Services;

namespace EmergencyApp.User.ViewModels;

public partial class HomeViewModel : ObservableObject
{
    private readonly DatabaseService _db;
    private readonly SessionService _session;
    private readonly LocationService _location;
    private readonly SyncService _sync;
    private readonly LiveTrackingService _tracker;

    public List<EmergencyTypeOption> Types => EmergencyTypeOption.All;

    [ObservableProperty] private EmergencyTypeOption? selectedType;
    [ObservableProperty] private string statusText = "";
    [ObservableProperty] private string greeting = "";
    [ObservableProperty] private bool isBusy;
    [ObservableProperty] private bool isTracking;
    [ObservableProperty] private string trackingText = "";

    public HomeViewModel(DatabaseService db, SessionService session, LocationService location,
                         SyncService sync, LiveTrackingService tracker)
    {
        _db = db; _session = session; _location = location; _sync = sync; _tracker = tracker;
        _tracker.Changed += OnTrackingChanged;
    }

    public void OnAppearing()
    {
        Greeting = $"Hello, {_session.CurrentUser?.FullName.Split(' ')[0]}";
        OnTrackingChanged(); // Refresh the banner if this transient view model was recreated.
    }

    private void OnTrackingChanged() => MainThread.BeginInvokeOnMainThread(() =>
    {
        IsTracking = _tracker.IsActive;
        TrackingText = _tracker.LastSentUtc is { } t
            ? $"Last location sent {t.ToLocalTime():HH:mm:ss}"
            : "Waiting for a GPS fix…";
        if (_tracker.LastError is { } err) TrackingText += $"\n⚠️ {err}";
    });

    [RelayCommand]
    private async Task SendSosAsync()
    {
        if (IsBusy || _session.CurrentUser is null) return;
        if (SelectedType is null)
        {
            await Shell.Current.DisplayAlert("Choose type", "Select the type of emergency first.", "OK");
            return;
        }
        if (!await Shell.Current.DisplayAlert("Send SOS",
                $"Send a {SelectedType.Name} emergency and share your live location with responders?", "SEND", "Cancel"))
            return;

        IsBusy = true; StatusText = "Getting your location…";
        try
        {
            var loc = await _location.GetCurrentAsync();
            var req = new EmergencyRequest
            {
                UserId = _session.CurrentUser.Id,
                Type = SelectedType.Name,
                Latitude = loc?.Latitude,
                Longitude = loc?.Longitude,
            };
            await _db.SaveRequestAsync(req);   // always saved locally first (offline-safe)

            StatusText = "Sending…";
            var sent = await _sync.PushAsync(req);
            StatusText = sent
                ? "✅ Help request sent. Your live location is being shared until the request is closed."
                : "⚠️ No connection. Saved on your phone and will send when you open History / reconnect. Call the emergency number now if urgent.";
            if (loc is null) StatusText += "\n📍 Location was unavailable.";

            if (sent) _tracker.Start(req);     // start live location updates
            SelectedType = null;
        }
        finally { IsBusy = false; }
    }

    [RelayCommand]
    private void StopSharing()
    {
        _tracker.Stop();
        StatusText = "Live location sharing stopped. Your request is still open.";
    }

    [RelayCommand]
    private async Task CallEmergencyAsync()
    {
        var number = Preferences.Get("emergency_number", "911");
        try { PhoneDialer.Default.Open(number); }
        catch { await Shell.Current.DisplayAlert("Error", "Cannot open the phone dialer.", "OK"); }
    }
}
