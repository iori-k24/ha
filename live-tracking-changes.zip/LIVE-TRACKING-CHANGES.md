# Live tracking + slimmer SOS — what changed and how to apply

Copy these files over your repo (same folder structure), then:

## 1. Database (one time)
The server creates tables with `EnsureCreated`, which does NOT add new columns to an existing database.
Pick one:
- Dev data not needed: in MySQL run `DROP DATABASE emergency_db;` — it is recreated on next server start.
- Keep your data: run
  `ALTER TABLE Incidents ADD COLUMN LocationUpdatedAt datetime(6) NULL;`

## 2. Desktop app
- Restore NuGet packages (adds `Microsoft.Web.WebView2`). If restore complains about the version, install the latest `Microsoft.Web.WebView2` from NuGet.
- The map needs internet (Leaflet + OpenStreetMap tiles) and the Microsoft Edge WebView2 Runtime (already on Windows 11 and most Windows 10 PCs).

## 3. Test
1. Start server, desk app, phone app (emulator: set a location in Extended Controls > Location, then change it).
2. Phone: pick a type, press SOS. A green "Sharing live location" banner appears.
3. Desk: Incidents > select the incident. The map shows the marker + trail, "● LIVE · updated Ns ago".
4. Desk: set status Resolved. The phone stops sharing on its next tick.

## What changed
- SOS payload is now only: type, location, timestamp (no description text, no userId — the server uses the login token).
- New endpoint: POST /api/emergencies/{id}/location (owner only, stops accepting after Resolved/Cancelled).
- Phone: LiveTrackingService (every 5 s while the app is open), new Home screen with big SOS button + Stop sharing.
- Desk: map panel in Incident details, live/last-known indicator, Reporter column replaces Description.

## Known limits
- Tracking runs while the app is open; Android may pause it when the app is in the background or the screen is off. A foreground service is the next step.
- If the SOS was sent offline, tracking does not start automatically when it syncs later.
- Not compiled here (no .NET SDK in my environment) — send me any build errors.
