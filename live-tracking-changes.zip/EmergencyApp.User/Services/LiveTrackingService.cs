using EmergencyApp.User.Models;

namespace EmergencyApp.User.Services;

/// <summary>
/// While an SOS is open, sends the phone's position to the server every few seconds so the
/// desk can follow the person on a map. Stops when the incident is Resolved/Cancelled,
/// when the user presses "Stop sharing", on sign-out, or after repeated server errors.
/// Works while the app is open (a background/foreground service is a later step).
/// </summary>
public class LiveTrackingService
{
    private static readonly TimeSpan Interval = TimeSpan.FromSeconds(5);
    private const int MaxServerErrors = 5;

    private readonly ApiService _api;
    private readonly SessionService _session;
    private readonly DatabaseService _db;
    private readonly LocationService _location;
    private CancellationTokenSource? _cts;

    public LiveTrackingService(ApiService api, SessionService session, DatabaseService db, LocationService location)
        => (_api, _session, _db, _location) = (api, session, db, location);

    public bool IsActive => _cts is not null;
    public DateTime? LastSentUtc { get; private set; }
    public string? LastError { get; private set; }

    /// <summary>Raised from a background thread whenever state changes.</summary>
    public event Action? Changed;

    public void Start(EmergencyRequest request)
    {
        if (request.ServerId is null) return;   // not on the server yet, nothing to attach to
        Stop();

        var cts = new CancellationTokenSource();
        _cts = cts;
        LastSentUtc = null;
        LastError = null;
        _ = RunAsync(request, cts);
        Changed?.Invoke();
    }

    public void Stop()
    {
        var cts = _cts;
        _cts = null;
        cts?.Cancel();
        Changed?.Invoke();
    }

    private async Task RunAsync(EmergencyRequest request, CancellationTokenSource cts)
    {
        var ct = cts.Token;
        var serverErrors = 0;
        try
        {
            using var timer = new PeriodicTimer(Interval);
            do
            {
                if (_session.CurrentUser is null) break;   // signed out

                // Geolocation and permission checks must run on the UI thread.
                var loc = await MainThread.InvokeOnMainThreadAsync(() => _location.GetQuickAsync());
                if (loc is not null)
                {
                    var update = new LocationUpdateDto(loc.Latitude, loc.Longitude, DateTime.UtcNow);
                    var res = await _api.SendLocationAsync(request.ServerId!.Value, update, _session.Token);

                    if (res.Success && res.Data is not null)
                    {
                        serverErrors = 0;
                        LastSentUtc = DateTime.UtcNow;
                        LastError = null;

                        request.Latitude = loc.Latitude;
                        request.Longitude = loc.Longitude;
                        request.Status = res.Data.Status;
                        request.ResponderName = res.Data.ResponderName;
                        await _db.SaveRequestAsync(request);

                        if (res.Data.Status is RequestStatus.Resolved or RequestStatus.Cancelled) break;
                    }
                    else
                    {
                        LastError = res.Error;
                        if (!res.Offline && ++serverErrors >= MaxServerErrors) break;
                    }
                }
                Changed?.Invoke();
            }
            while (await timer.WaitForNextTickAsync(ct));
        }
        catch (OperationCanceledException) { /* stopped by the user */ }
        finally
        {
            if (ReferenceEquals(_cts, cts)) _cts = null;
            Changed?.Invoke();
        }
    }
}
