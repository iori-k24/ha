using System.Text.Json.Serialization;

namespace EmergencyDesk.Models;

public enum IncidentStatus { Received, Dispatched, EnRoute, OnScene, Resolved, Cancelled }
public enum IncidentType { Medical, Fire, Police, Rescue }
public enum ResponderStatus { Available, Busy, OffDuty }

public class LoginRequest
{
    public string Username { get; set; } = "";
    public string Password { get; set; } = "";
}

public class LoginResponse
{
    public string Token { get; set; } = "";
    public string DisplayName { get; set; } = "";
    /// <summary>"Admin" or "Dispatcher"</summary>
    public string Role { get; set; } = "";
}

public class Incident
{
    public int Id { get; set; }
    public IncidentType Type { get; set; }
    public IncidentStatus Status { get; set; }
    public string Description { get; set; } = "";
    public string ReporterName { get; set; } = "";
    public string ReporterPhone { get; set; } = "";
    public double Latitude { get; set; }
    public double Longitude { get; set; }
    public string? Address { get; set; }
    public DateTime ReportedAt { get; set; }
    public int? AssignedResponderId { get; set; }
    public string? AssignedResponderName { get; set; }
    public DateTime? LocationUpdatedAt { get; set; }

    [JsonIgnore] public bool HasLocation => Latitude != 0 || Longitude != 0;
    [JsonIgnore] public bool IsFinished => Status is IncidentStatus.Resolved or IncidentStatus.Cancelled;
    /// <summary>True while the phone is still sending positions (last one under 30 s old).</summary>
    [JsonIgnore] public bool IsLive => HasLocation && !IsFinished && LocationUpdatedAt is { } t
                                       && (DateTime.UtcNow - t) < TimeSpan.FromSeconds(30);
    [JsonIgnore] public string LocationStatus
    {
        get
        {
            if (!HasLocation) return "No location shared";
            if (LocationUpdatedAt is not { } t) return "Location received";
            var age = DateTime.UtcNow - t;
            var ago = age.TotalSeconds < 10 ? "just now"
                    : age.TotalMinutes < 1 ? $"{(int)age.TotalSeconds}s ago"
                    : age.TotalHours < 1 ? $"{(int)age.TotalMinutes} min ago"
                    : $"{(int)age.TotalHours} h ago";
            return IsLive ? $"● LIVE · updated {ago}" : $"Last known · {ago}";
        }
    }

    [JsonIgnore] public string Coordinates => $"{Latitude:F5}, {Longitude:F5}";
    [JsonIgnore] public string ReportedLocal => ReportedAt.ToLocalTime().ToString("g");
}

public class Responder
{
    public int Id { get; set; }
    public string Name { get; set; } = "";
    public string Unit { get; set; } = "";      // e.g. "Ambulance 3", "Engine 12"
    public IncidentType Specialty { get; set; }
    public ResponderStatus Status { get; set; }
    public string Phone { get; set; } = "";
}

public class AppUser
{
    public int Id { get; set; }
    public string FullName { get; set; } = "";
    public string Email { get; set; } = "";
    public string Phone { get; set; } = "";
    public bool IsActive { get; set; }
    public DateTime RegisteredAt { get; set; }

    [JsonIgnore] public string RegisteredLocal => RegisteredAt.ToLocalTime().ToString("d");
}

public class AssignRequest { public int ResponderId { get; set; } }
public class StatusRequest { public IncidentStatus Status { get; set; } }
public class ActiveRequest { public bool IsActive { get; set; } }
